#!/bin/sh
WITH_TIMINGS=1 nosetests -s -q
